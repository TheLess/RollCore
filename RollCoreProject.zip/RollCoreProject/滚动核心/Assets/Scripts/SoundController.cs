﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void PlayAttacksound()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[5], new Vector3(0, 0, 0));
    }

    void PlayMisssound()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[6], new Vector3(0, 0, 0));
    }

    void PlayBulletsound()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[4], new Vector3(0, 0, 0));
    }
}
