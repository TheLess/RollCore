﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class ButtonController : MonoBehaviour
{
    //public GameObject AudioClick = new GameObject();
    //public GameObject AudioGameover = new GameObject();
    //public GameObject AudioWin = new GameObject();
    public GameObject MenuParent = new GameObject();
    int temp = 0;
    //public AudioSource AudioButton;
    // Start is called before the first frame update
    void Start()
    {
       // AudioButton = gameObject.GetComponent<AudioSource>();
    }

    private void Update()
    {
    }
    public void StartOnClick()
    {
        //AudioButton.playOnAwake = true;

        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
        
        //this.GetComponent<AudioSource>().Play();
        SceneManager.LoadScene("Menu");
    }
    public void backToStart()
    {
         AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
        SceneManager.LoadScene("Start");
    }

    public void backToGame()
    {
        
        Time.timeScale = 1;
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
        MenuParent.SetActive(false);
    }

    //choose level
    public void LevelChoice()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
        spawnparent.Totlenum = 0;
        SceneManager.LoadScene(this.gameObject.name);
    }

    public void NextLevel()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
        spawnparent.Totlenum = 0;
        SceneManager.LoadScene(this.gameObject.scene.buildIndex + 1);
        
    }

    public void QuitGame()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
        //AudioSource.PlayClipAtPoint(buttonAudio, new Vector3(0, 0, 0));
        //AudioButton.playOnAwake = true;
        Application.Quit();
    }
}
