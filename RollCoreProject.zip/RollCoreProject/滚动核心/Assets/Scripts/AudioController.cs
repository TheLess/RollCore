﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioController : MonoBehaviour
{
    public static AudioController _instance;
    public AudioClip[] AudioList=new AudioClip[10];

    private void Awake()
    {
        if(_instance == null)
        {
            DontDestroyOnLoad(this);
            _instance = this;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
