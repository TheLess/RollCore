﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarCreate : MonoBehaviour
{
    //test
    //int test = 5;

    public GameObject Bar = null;
    public float offset = 0.5f;
    public int RandomNum;
    GameObject[] Bars ;
    public GameObject parentBar;
    public float velocity = 1.0f;
    float score = 0;
    bool isPressed = false;
    public float maxHeight;
    static bool isenter = false;
    public int type = -1;

    float destroyTime = 0.5f;

    // Start is called before the first frame update
    void Start()
    {
        RandomNum = Random.Range(3, 6);

        Bars = new GameObject[RandomNum];

        for(int i = 0;  i <RandomNum; i++)
        {
            Bars[i] = Instantiate(Bar, Bar.transform.position, Quaternion.identity);
            Bars[i].transform.position = new Vector3(Bars[i].transform.position.x + offset* i, Bars[i].transform.position.y, Bars[i].transform.position.z);
            Bars[i].transform.parent = parentBar.transform;
            
         }

        parentBar.transform.position = new Vector3(20 +spawnparent.Totlenum * 1 , 0, 0);
        spawnparent.Totlenum += RandomNum;

        // create a group of  little bars with different random height 
        float[] temp = new float[RandomNum];
        
        for(int i = 0; i < RandomNum; i++)
        {
            temp[i] = Random.Range(1, 6) / 2f;
            Bars[i].transform.localScale = new Vector3(Bars[i].transform.localScale.x, Bars[i].transform.localScale.y * temp[i], Bars[i].transform.localScale.z);
        }
        maxHeight = Mathf.Max(temp) *  0.5f;

        /*switch (RandomNum)
        {
            case 3:

                temp[0] = random.range(1, 6) / 2f;
                temp[1] = random.range(1, 6) / 2f;
                temp[2] = random.range(1, 6) / 2f;
                bars[0].transform.localscale = new vector3(bars[0].transform.localscale.x, bars[0].transform.localscale.y * temp[0], bars[0].transform.localscale.z);

                bars[1].transform.localscale = new vector3(bars[1].transform.localscale.x, bars[1].transform.localscale.y * temp[1], bars[1].transform.localscale.z);

                bars[2].transform.localscale = new vector3(bars[2].transform.localscale.x, bars[2].transform.localscale.y * temp[2], bars[2].transform.localscale.z);
                maxHeight = Mathf.Max(temp)  *0.5f;
                break;
            case 4:
                temp[0] = Random.Range(1, 6) / 2f;
                temp[1] = Random.Range(1, 6) / 2f;
                temp[2] = Random.Range(1, 6) / 2f;
                temp[3] = Random.Range(1, 6) / 2f;
                Bars[0].transform.localScale = new Vector3(Bars[0].transform.localScale.x, Bars[0].transform.localScale.y * temp[0], Bars[0].transform.localScale.z);
                Bars[1].transform.localScale = new Vector3(Bars[1].transform.localScale.x, Bars[1].transform.localScale.y * temp[1], Bars[1].transform.localScale.z);
                Bars[2].transform.localScale = new Vector3(Bars[2].transform.localScale.x, Bars[2].transform.localScale.y * temp[2], Bars[2].transform.localScale.z);
                Bars[3].transform.localScale = new Vector3(Bars[3].transform.localScale.x, Bars[3].transform.localScale.y * temp[3], Bars[3].transform.localScale.z);
                maxHeight = Mathf.Max(temp)*0.5f;
                break;
            case 5:
                temp[0] = Random.Range(1, 6) / 2f;
                temp[1] = Random.Range(1, 6) / 2f;
                temp[2] = Random.Range(1, 6) / 2f;
                temp[3] = Random.Range(1, 6) / 2f;
                temp[4] = Random.Range(1, 6) / 2f;

                Bars[0].transform.localScale = new Vector3(Bars[0].transform.localScale.x, Bars[0].transform.localScale.y * temp[0], Bars[0].transform.localScale.z);
                Bars[1].transform.localScale = new Vector3(Bars[1].transform.localScale.x, Bars[1].transform.localScale.y * temp[1], Bars[1].transform.localScale.z);
                Bars[2].transform.localScale = new Vector3(Bars[2].transform.localScale.x, Bars[2].transform.localScale.y * temp[2], Bars[2].transform.localScale.z);
                Bars[3].transform.localScale = new Vector3(Bars[3].transform.localScale.x, Bars[3].transform.localScale.y * temp[3], Bars[3].transform.localScale.z);
                Bars[4].transform.localScale = new Vector3(Bars[4].transform.localScale.x, Bars[4].transform.localScale.y * temp[4], Bars[4].transform.localScale.z);

                maxHeight = Mathf.Max(temp)*0.5f;

                break;

        }*/

    }


    private void FixedUpdate()
    {
        transform.position -= new Vector3(velocity, 0, 0);
        switch (RandomNum)
        {
            case 3:

                if (transform.position.x < -4.0f)
                {
                    Debug.Log("miss roll!");
                    if (!isPressed)
                    {
                        spawnparent.currentScore = 0;
                    }
                    GameObject.Find("1").GetComponent<spawnparent>().myEvent(type);
                    Destroy(gameObject);
                }
                if (parentBar.transform.position.x > -4 && parentBar.transform.position.x < 0.1)
                {
                    spawnparent.currentparrent = gameObject;
                }
                    break;
            case 4:
                if (transform.position.x < -5.4f)
                {
                    Debug.Log("miss roll!");
                    if (!isPressed)
                    {

                        spawnparent.currentScore = 0;
                    }
                    GameObject.Find("1").GetComponent<spawnparent>().myEvent(type);
                    Destroy(gameObject);
                }
                if (parentBar.transform.position.x > -5.41 && parentBar.transform.position.x < 0.1)
                {
                    spawnparent.currentparrent = gameObject;
                }
                    break;
            case 5:
                if (transform.position.x < -6.8f)
                {
                    Debug.Log("miss roll!");
                    if (!isPressed)
                    {
                        spawnparent.currentScore = 0;
                    }
                    GameObject.Find("1").GetComponent<spawnparent>().myEvent(type);
                    Destroy(gameObject);
                }
                if (parentBar.transform.position.x > -6.82 && parentBar.transform.position.x < 0.1)
                {
                    spawnparent.currentparrent = gameObject;
                }
                    break;
        }
    }
    // Update is called once per frame
    //IEnumerator Slowdown()
    //{

    //    //velocity /= 10;
    //    Time.timeScale = 0.5f;
    //    yield return new WaitForSeconds(0.2f);
    //    //velocity *= 10;
    //    Time.timeScale = 1;

    //    yield break;
    //}

    //set 
    void SetCurrentScore(float score)
    {
        if (score > 0.99)
        {
            spawnparent.currentScore = 10;
        }
        if (score < 0.99 && score > 0.65)
        {
            spawnparent.currentScore = 6;
        }
        if (score < 0.65 && score > 0)
        {
            spawnparent.currentScore = 2;
        }
    }

    void reaction()
    {
        //test
        //Debug.Log(test);
        //test = 3;
        //Debug.Log(test);

        isenter = true;
        switch (RandomNum)
        {
            case 3:
                if (parentBar.transform.position.x > -4 && parentBar.transform.position.x < 0.1)
                {
                    float diff = 0.1f - (-4f);
                    float single = diff / 3;
                    for (int i = 0; i < RandomNum; i++)
                    {
                        if (parentBar.transform.position.x > (0.1f - (i + 1) * single))
                        {
                            isPressed = true;

                            score = Bars[i].transform.localScale.y;
                            score = score / maxHeight;
                            Debug.Log("score: " + score);
                            SetCurrentScore(score);
                            //if (score > 0.99)
                            //{
                            //    spawnparent.currentScore = 10;
                            //}
                            //if (score < 0.99 && score > 0.65)
                            //{
                            //    spawnparent.currentScore = 6;
                            //}
                            //if (score < 0.65 && score > 0)
                            //{
                            //    spawnparent.currentScore = 2;
                            //}

                            //foreach (var go in spawnparent.Parents)
                            //{
                            //    if (go != null)
                            //         StartCoroutine(go.GetComponent<BarCreate>().Slowdown());
                            //}

                            StartCoroutine(GameObject.Find("1").GetComponent<spawnparent>().Slowdown());

                            for (int j = 0; j < RandomNum; j++)
                            {
                                Bars[j].GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, 0.1f);
                                
                            }
                            Debug.LogWarning("liang");
                            Bars[i].GetComponent<SpriteRenderer>().color = new Color(1.0f, 0, 0);
                            break;
                        }
                    }
                    Debug.Log("case 3 roll!");
                }

                break;
            case 4:
                if (parentBar.transform.position.x > -5.41 && parentBar.transform.position.x < 0.1)
                {
                    float diff = 0.1f - (-5.41f);
                    float single = diff / 4;
                    for (int i = 0; i < RandomNum; i++)
                    {
                        if (parentBar.transform.position.x > (0.1f - (i + 1) * single))
                        {
                            score = Bars[i].transform.localScale.y;
                            //StartCoroutine(Slowdown());
                            isPressed = true;
                            score = score / maxHeight;

                            Debug.Log("score: " + score);

                            SetCurrentScore(score);
                            //if (score > 0.99)
                            //{
                            //    spawnparent.currentScore = 10;
                            //}
                            //if (score < 0.99 && score > 0.65)
                            //{
                            //    spawnparent.currentScore = 6;
                            //}
                            //if (score < 0.65 && score > 0)
                            //{
                            //    spawnparent.currentScore = 2;
                            //}

                            //foreach (var go in spawnparent.Parents)
                            //{
                            //    if (go != null)
                            //         StartCoroutine(go.GetComponent<BarCreate>().Slowdown());
                            //}

                            StartCoroutine(GameObject.Find("1").GetComponent<spawnparent>().Slowdown());
                            for (int j = 0; j < RandomNum; j++)
                            {
                                Bars[j].GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, 0.1f);
                               
                            }
                            Debug.LogWarning("liang");
                            Bars[i].GetComponent<SpriteRenderer>().color = new Color(1.0f, 0, 0);
                            break;
                        }
                    }

                    Debug.Log("case 4 roll!");
                }

                break;
            case 5:
                if (parentBar.transform.position.x > -6.82 && parentBar.transform.position.x < 0.1)
                {
                    float diff = 0.1f - (-6.82f);
                    float single = diff / 5;
                    for (int i = 0; i < RandomNum; i++)
                    {
                        if (parentBar.transform.position.x > (0.1f - (i + 1) * single))
                        {
                            score = Bars[i].transform.localScale.y;

                            isPressed = true;
                            score = score / maxHeight;
                            Debug.Log("score: " + score);

                            SetCurrentScore(score);
                            //if (score > 0.99)
                            //{
                            //    spawnparent.currentScore = 10;
                            //}
                            //if (score < 0.99 && score > 0.65)
                            //{
                            //    spawnparent.currentScore = 6;
                            //}
                            //if (score < 0.65 && score > 0)
                            //{
                            //    spawnparent.currentScore = 2;
                            //}

                            //foreach (var go in spawnparent.Parents)
                            //{
                            //    if (go != null)
                            //         StartCoroutine(go.GetComponent<BarCreate>().Slowdown());
                            //}

                            StartCoroutine(GameObject.Find("1").GetComponent<spawnparent>().Slowdown());
                            for (int j = 0; j < RandomNum; j++)
                            {
                                Bars[j].GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, 0.1f);
                               
                            }
                            Debug.LogWarning("liang");
                            Bars[i].GetComponent<SpriteRenderer>().color = new Color(1.0f, 0, 0);
                            break;
                        }
                    }
                    Debug.Log("case 5 roll!");
                }
                break;

        }
    }
    void Update()
    {
        //test
        //Debug.Log(test);
        //test = 3;
        //Debug.Log(test);

        //Debug.Log(isenter);
        if (!isPressed && type == spawnparent.currentparrent.GetComponentInChildren<BarCreate>().type)
        {
            if (Input.GetKeyUp(KeyCode.S))
            {
                if (type == 2)
                {
                    reaction();
                    //Debug.Log("i:" + isenter);
                }
                else
                {
                    if(!isenter)
                    {
                        //Debug.Log("i:" + isenter);
                        //Debug.Log("gg");
                        foreach (var go in spawnparent.currentparrent.GetComponentsInChildren<SpriteRenderer>())
                        {
                            go.color = new Color(0, 0, 0, 0.1f);
                        }
                    }
                }
                isenter = false;
            }

            //Camera.main.GetComponent<Animator>().SetTrigger("doudong");

            else if (Input.GetKeyUp(KeyCode.W))
            {
                if (type == 0)
                {
                    reaction();
                }
                else
                {
                    if (!isenter)
                    {
                        foreach (var go in spawnparent.currentparrent.GetComponentsInChildren<SpriteRenderer>())
                        {
                            go.color = new Color(0, 0, 0, 0.1f);
                        }
                    }
                }
                isenter = false;
                //Camera.main.GetComponent<Animator>().SetTrigger("doudong");
            }
            else if (Input.GetKeyUp(KeyCode.A))
            {
                if (type == 1)
                {
                    reaction();
                }
                else
                {
                    if (!isenter)
                    {
                        foreach (var go in spawnparent.currentparrent.GetComponentsInChildren<SpriteRenderer>())
                        {
                            go.color = new Color(0, 0, 0, 0.1f);
                        }
                    }
                }
                isenter = false;
                //Camera.main.GetComponent<Animator>().SetTrigger("doudong");
            }
            else if (Input.GetKeyUp(KeyCode.D))
            {
                if (type == 3)
                {
                    reaction();
                }
                else
                {
                    if (!isenter)
                    {
                        foreach (var go in spawnparent.currentparrent.GetComponentsInChildren<SpriteRenderer>())
                        {
                            go.color = new Color(0, 0, 0, 0.1f);
                        }
                    }
                }
                isenter = false;
                // Camera.main.GetComponent<Animator>().SetTrigger("doudong");

            }
        }
    }
}

