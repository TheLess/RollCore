﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class spawnparent : MonoBehaviour
{
    public GameObject[] parentPrefabs = new GameObject[4];
    public GameObject[] hps = new GameObject[10];
    public GameObject[] energys = new GameObject[10];
    public GameObject[] enemys = new GameObject[15];

    //charactors
    public GameObject Player = new GameObject() ;
    public GameObject enemy = new GameObject();



    public GameObject GameoverMenu = new GameObject();
    public GameObject WinMenu = new GameObject();
    public GameObject GamePauseMenu = new GameObject();

    public static GameObject currentparrent = null;
    public static int currentScore = -1;
    public static int currentLevel = -1;
    public Text scoreText;
    public Text CurrentLevelText;
    int currentType;
    int countTime = 0;
    public static int num = 1;
    public static int Totlenum = 0;
    public static List<GameObject> Parents = new List<GameObject>();
    public Text eventText;
    float offset =5;

    public int health = 10;
    public int healthEnemy = 15;
    public int power = 10;
    bool isstop = false;
   // bool isPressed = false;

    // Start is called before the first frame update
    void Start()
    {
        //first level is scene 2
        

        Debug.Log("currentScore" + currentScore);
        currentLevel = gameObject.scene.buildIndex - 1;

        //Debug.Log("scene :" + this.gameObject.scene.rootCount);
        Time.timeScale = 1;
    }

    //Pause the Game
    void GamePause()
    {
        Time.timeScale = 0;
    }

    //continue the Game
    void GameContinue()
    {
        Time.timeScale = 1;
    }

    void clearHealth()
    {
        //Debug.Log("enter clearhealth");
        for (int i = 0; i < 10; i++)
        {
            //Debug.Log("enter " + i + "set hp false");
            //Debug.Log(("before i: " + i) + hps[i].activeSelf);
            hps[i].SetActive(false);
            //Debug.Log(("After i: " + i) + hps[i].activeSelf);

        }
    }

    void clearHealthEnemy()
    {
        for (int i = 0; i < 10; i++)
        {
            enemys[i].SetActive(false);
        }
    }
    //Pause the Game
    void GamePaused()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
        Debug.Log("timeScale: " + Time.timeScale);
        GamePause();
        Debug.Log("after timeScale: " + Time.timeScale);
        GamePauseMenu.SetActive(true);

    }

    //when Game over
    void Gameover()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[2], new Vector3(0, 0, 0));
        health = 0;
        clearHealth();
        //Debug.Log("clearHealth finished");
        GamePause();
        GameoverMenu.SetActive(true);
        Debug.Log("game over");

    }

    //win pass the level
    void Win()
    {
        AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[1], new Vector3(0, 0, 0));
        healthEnemy = 0;
        clearHealthEnemy();
        GamePause();
        WinMenu.SetActive(true);
    }

   
    private void FixedUpdate()
    {
        if (!isstop)
            Time.timeScale = 1;
        else
            Time.timeScale = 0.3f;
        countTime++;
        if(countTime % 200 == 0)
        {
            if (power < 10)
                power += 1;
        }
        if(countTime % 50 == 0)
        {
            num += 1;
            int tempTpye = Random.Range(0,4 );
           // tempTpye = 2;
            GameObject go = Instantiate(parentPrefabs[tempTpye]);
            go.GetComponent<BarCreate>().type = tempTpye;
            Parents.Add(go);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(this.gameObject.scene.buildIndex == 3)
        {
            Time.timeScale  = Time.timeScale * 1.5f;

        }
        //if (!isPressed)
        //{
        CurrentLevelText.text = "Level " + currentLevel;
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            AudioSource.PlayClipAtPoint(AudioController._instance.AudioList[0], new Vector3(0, 0, 0));
            // isPressed = true;
            GamePaused();
        }
        //}

        for (int i = 0; i < 10; i++)
        {
            hps[i].SetActive(false);
            energys[i].SetActive(false);
        }
        for (int i = 0; i < 15; i++)
        {
            enemys[i].SetActive(false);
        }

        //scoreText.text ="currentscore: " +  currentScore.ToString();
        for(int i =0;i<health;i++)
        {
            hps[i].SetActive(true);

        }
        for (int i = 0; i < power; i++)
        {
            energys[i].SetActive(true);

        }
        for (int i = 0; i < healthEnemy; i++)
        {
            enemys[i].SetActive(true);

        }
    }

    public  IEnumerator Slowdown()
    {

        //velocity /= 10;
        //Time.timeScale = 0.3f;
        isstop = true;
        yield return new WaitForSeconds(0.1f);
        isstop = false;
        //velocity *= 10;
        //Time.timeScale = 1;
        yield return null;
    }

    //jump 0, roll 2, defense 
    IEnumerator event0()
    {
        //eventText.gameObject.SetActive(true);
        //ispowerPositive 

        if (currentScore == 10)
        {

            Player.GetComponent<Animator>().SetTrigger("Miss");
            enemy.GetComponent<Animator>().SetTrigger("Bottom");
            //eventText.text = "roll prefect, power --0 , health -- 0";

        }
        if (currentScore == 6)
        {

            Player.GetComponent<Animator>().SetTrigger("Miss");
            enemy.GetComponent<Animator>().SetTrigger("Bottom");
            if ((power - 2) > 0)
            {
                power -= 2;
            }
            else
            {
                power = 0;
                int temp = 2 - power;

                if (health - temp > 0)
                {
                    health -= temp;
                }
                else
                {
                    Gameover();
                }

            }
            //eventText.text = "roll great, power --2 , health -- 0";

        }
        if (currentScore == 2)
        {

            Player.GetComponent<Animator>().SetTrigger("Miss");
            enemy.GetComponent<Animator>().SetTrigger("Bottom");
            //eventText.text = "roll poor, power --3 , health -- 0";
            if ((power - 3) >= 0)
            {
                power -= 3;
            }
            else
            {
                power = 0;
                int temp = 5 - power;
                if (health - temp > 0)
                    health -= temp;
                else
                {
                    Gameover();
                }

            }
        }
        if (currentScore == 0)
        {

            Player.GetComponent<Animator>().SetTrigger("BeAttack");
            enemy.GetComponent<Animator>().SetTrigger("Bottom");
            //eventText.text = "not roll, power --0 , health -- 2";
            int temp = 2;
            if (health - temp > 0)
                health -= temp;
            else
            {

                Gameover();
            }

        }
        yield return new WaitForSeconds(0.45f);
        //eventText.gameObject.SetActive(false);

        yield break;
    }
    IEnumerator event1()
    {
        //eventText.gameObject.SetActive(true);
        //ispowerPositive 

        if (currentScore == 10)
        {

            Player.GetComponent<Animator>().SetTrigger("Miss");
            enemy.GetComponent<Animator>().SetTrigger("Attack");
            //eventText.text = "roll prefect, power --0 , health -- 0";

        }
        if (currentScore == 6)

        {

            Player.GetComponent<Animator>().SetTrigger("BeAttack");
            enemy.GetComponent<Animator>().SetTrigger("Attack");
            if ((power - 2) > 0)
            {
                power -= 2;
            }
            else
            {
                power = 0;
                int temp = 2 - power;

                if (health - temp > 0)
                {
                    health -= temp;
                }
                else
                {
                    Gameover();
                }

            }
            //eventText.text = "roll great, power --2 , health -- 0";

        }
        if (currentScore == 2)
        {
            Player.GetComponent<Animator>().SetTrigger("BeAttack");
            enemy.GetComponent<Animator>().SetTrigger("Attack");
            //eventText.text = "roll poor, power --3 , health -- 0";
            if ((power - 3) >= 0)
            {
                power -= 3;
            }
            else
            {
                power = 0;
                int temp = 5 - power;
                if (health - temp > 0)
                    health -= temp;
                else
                {
                    Gameover();
                }

            }
        }
        if (currentScore == 0)
        {
            Player.GetComponent<Animator>().SetTrigger("BeAttack");
            enemy.GetComponent<Animator>().SetTrigger("Attack");
            //eventText.text = "not roll, power --0 , health -- 2";
            int temp = 2;
            if (health - temp > 0)
                health -= temp;
            else
            {

                Gameover();
            }

        }
        yield return new WaitForSeconds(0.45f);
        //eventText.gameObject.SetActive(false);

        yield break;
    }
    IEnumerator event2()
    {

        //eventText.gameObject.SetActive(true);
        //ispowerPositive 

        if (currentScore == 10)
        {

            Player.GetComponent<Animator>().SetTrigger("Miss");
            enemy.GetComponent<Animator>().SetTrigger("Mid");
            //eventText.text = "roll prefect, power --0 , health -- 0";

        }
        if (currentScore == 6)
        {

            Player.GetComponent<Animator>().SetTrigger("Miss");
            enemy.GetComponent<Animator>().SetTrigger("Mid");
            if ((power - 2) > 0)
            {
                power -= 2;
            }
            else
            {
                power = 0;
                int temp = 2 - power;

                if (health - temp > 0)
                {
                    health -= temp;
                }
                else
                {
                    Gameover();
                }
                    
            }
           // eventText.text = "roll great, power --2 , health -- 0";
          
        }
        if(currentScore == 2)
        {

            Player.GetComponent<Animator>().SetTrigger("Miss");
            enemy.GetComponent<Animator>().SetTrigger("Mid");

            //eventText.text = "roll poor, power --3 , health -- 0";
            if ((power - 3) >= 0)
            {
                power -= 3;
            }
            else
            {
                power = 0;
                int temp = 5 - power;
                if (health - temp > 0)
                    health -= temp;
                else
                {
                    Gameover();
                }
                    
            }
        }
        if(currentScore == 0)
        {
            
            enemy.GetComponent<Animator>().SetTrigger("Mid");
            //eventText.text = "not roll, power --0 , health -- 2";
            int temp = 2;
            if (health - temp > 0)
                health -= temp;
            else
            {

                Gameover();
            }

        }
        yield return new WaitForSeconds(0.45f);
        //eventText.gameObject.SetActive(false);

        yield break;
    }

    //attack 3
    IEnumerator event3()
    {
        if (currentScore == 10)
        {
            Player.GetComponent<Animator>().SetTrigger("Attack");
            enemy.GetComponent<Animator>().SetTrigger("BeAttack");
            if(healthEnemy - 4 > 0)
                healthEnemy -= 4;
            else
            {
                Win();
            }
        }
        if (currentScore == 6)
        {

            Player.GetComponent<Animator>().SetTrigger("Attack");
            enemy.GetComponent<Animator>().SetTrigger("BeAttack");
            if (healthEnemy - 2 > 0)
                healthEnemy -= 2;
            else
            {
                Win();
            }
        }
        if (currentScore == 2)
        {

            Player.GetComponent<Animator>().SetTrigger("Attack");
            enemy.GetComponent<Animator>().SetTrigger("BeAttack");
            if (healthEnemy - 1 > 0)
                healthEnemy -= 1;
            else
            {
                Win();
            }
        }
        yield break;

    }
    public void myEvent(int eventType)
    {
        //eventType:0 jump, 1 defense, 2 roll, 3 attack
        switch(eventType)
        {
            case 0:
                StartCoroutine(event0());
                break;
            case 1:
                StartCoroutine(event1());
                break;

            case 2:
                StartCoroutine(event2());
                break;
            case 3:
                StartCoroutine(event3());
                break;


        }
    }
}
